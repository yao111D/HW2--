import requests, time, json
url = "http://localhost:30000/generate"
results = []
print("=== 开始 32 条分散前缀测试 ===")
for i in range(32):
    prompt = f"Unique test {i}: " + "A random sentence " * 200
    payload = {"text": prompt, "sampling_params": {"temperature": 0.0, "max_new_tokens": 16, "ignore_eos": True}, "stream": False}
    start_time = time.time()
    try:
        response = requests.post(url, json=payload, timeout=30)
        response.raise_for_status()
        data = response.json()
        latency = time.time() - start_time
        meta = data.get("meta_info", {})
        results.append({"request_id": i, "latency": latency, "prompt_tokens": meta.get("prompt_tokens", 0), "cached_tokens": meta.get("cached_tokens", 0), "completion_tokens": meta.get("completion_tokens", 0)})
        print(f"请求 {i+1}/32 完成 | 耗时: {latency:.3f}s | 输入: {meta.get('prompt_tokens')} | 缓存命中: {meta.get('cached_tokens')}")
    except Exception as e:
        print(f"请求 {i+1} 失败: {e}")
print("\n=== 测试结束 ===")
with open("dispersed_prefix_results.json", "w") as f:
    json.dump(results, f, indent=4)
print("结果已保存到 dispersed_prefix_results.json")
