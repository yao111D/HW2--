# HW2-姚宁敏

## 1. GPU 与软件版本

- **GPU**: NVIDIA GeForce RTX 3080 Ti (12GB)
- **云平台**: AutoDL
- **软件版本**: SGLang 0.5.14, Ray 2.56.0
- **模型**: Qwen/Qwen3-0.6B
- **CUDA 版本**: 13.0

## 2. 安装方法

在云服务器终端执行以下命令：

```bash
pip install sglang==0.5.14 ray==2.56.0
pip install modelscope
export SGLANG_USE_MODELSCOPE=true
```

3. 启动与回放命令

启动 SGLang 服务

```bash
python -m sglang.launch_server --model-path Qwen/Qwen3-0.6B --port 30000
```

(注：SGLang 0.5.14 版本中 Radix Cache 默认开启，无需添加额外参数)回放测试脚本

```bash
# 1. 运行共享前缀组测试
python test_task1.py

# 2. 运行分散前缀组测试
python test_task2.py

# 3. 统计指标
python calc_stats.py
```

4. 脚本用途

· test_task1.py: 构造并发送 32 条包含共享前缀的请求，测量 SGLang 的缓存命中情况。
· test_task2.py: 构造并发送 32 条无共享前缀的请求，作为实验对照组。
· calc_stats.py: 读取测试生成的 JSON 数据，计算成功率、缓存命中率、p50、p95 等统计指标。

5. 结果目录与报告表格的对应关系

· 报告中 “共享前缀组” 表格的数据，来源于 results/target1/shared_prefix/shared_prefix_results.json。
· 报告中 “分散前缀组” 表格的数据，来源于 results/target1/dispersed_prefix/dispersed_prefix_results.json。
